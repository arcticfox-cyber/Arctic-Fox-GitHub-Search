#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Arctic Fox GitHub Search v4.0 — GUI Edition (Kali Linux).

A desktop GUI for inspecting GitHub accounts and repositories.
Arctic Ice theme · English UI · standard library only (Tkinter).

Usage:
    python3 arcticfox-gui.py [username]
    af  [username]          (after install.sh)
    af  --cli [username]    terminal edition
"""

import base64
import math
import os
import queue
import sys
import threading
import webbrowser
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

# ---- friendly start-up guard: never crash with a raw traceback -------------
def _gui_unavailable(reason):
    """Explain why the GUI cannot start and offer terminal mode instead."""
    bar = "─" * 58
    print(f"\n  {bar}\n")
    print("   ARCTIC FOX v4.0 — GUI cannot start\n")
    print(f"   Reason: {reason}\n")
    print("   FIX (run these commands, then try again):")
    print("     sudo apt update")
    print("     sudo apt install -y python3 python3-tk")
    print("\n   No desktop available (SSH / headless / Termux)?")
    print("     Use terminal mode instead:  python3 arcticfox-cli.py\n")
    try:
        ans = input("   Start terminal mode now? [Y/n] ").strip().lower()
    except (EOFError, KeyboardInterrupt):
        ans = "n"
    if ans in ("", "y", "yes"):
        os.execv(sys.executable,
                 [sys.executable,
                  str(Path(__file__).resolve().parent / "arcticfox-cli.py")]
                 + sys.argv[1:])
    sys.exit(1)


try:
    import tkinter as tk
    import tkinter.font as tkfont
    from tkinter import filedialog, messagebox, ttk
except ImportError:
    # --version / --help still work without tkinter
    if any(a in ("-v", "--version", "-h", "--help") for a in sys.argv[1:]):
        if any(a in ("-v", "--version") for a in sys.argv[1:]):
            print("Arctic Fox GitHub Search 4.0 (GUI edition)")
        else:
            print(__doc__)
        sys.exit(0)
    _gui_unavailable("Tkinter (python3-tk) is not installed.")

import arcticfox_core as core  # noqa: E402


# ----------------------------------------------------------------- theme --
class C:
    """Arctic Ice palette."""
    bg        = "#0A1220"   # deepest background
    panel     = "#0E1830"   # panels / bars
    card      = "#101C36"   # cards
    card2     = "#0D1730"   # alternating rows
    border    = "#1D3A5F"
    border2   = "#25497A"
    ice       = "#6FD3FF"   # primary accent
    cyan      = "#22D3EE"
    blue      = "#3B82F6"
    deep      = "#1E5B8C"
    text      = "#E8F2FF"
    muted     = "#7E96B8"
    faint     = "#4C6285"
    ok        = "#3DDC97"
    warn      = "#FFC24B"
    danger    = "#FF6B7A"
    white     = "#FFFFFF"
    selbg     = "#1B4965"


_FAMILIES = None


def _families():
    global _FAMILIES
    if _FAMILIES is None:
        try:
            _FAMILIES = set(tkfont.families())
        except Exception:
            _FAMILIES = set()
    return _FAMILIES


def font_of(family=None, size=10, bold=False, mono=False):
    if family is None:
        try:
            family = tkfont.nametofont("TkFixedFont" if mono else "TkDefaultFont").actual("family")
        except Exception:
            family = "TkFixedFont" if mono else "TkDefaultFont"
        prefs = (("DejaVu Sans Mono", "Liberation Mono", "Noto Sans Mono") if mono
                 else ("DejaVu Sans", "Noto Sans", "Liberation Sans"))
        for c in prefs:
            if c in _families():
                family = c
                break
    return (family, size, "bold" if bold else "normal")


# ASCII arctic fox — shown with an animated ice gradient in the header.
FOX_ART = [
    r"   /\______/\   ",
    r"  /  o    o  \  ",
    r" (  ==  ^  ==  ) ",
    r"  )           (  ",
    r" (             ) ",
    r"(  (  )   (  )  )",
    r" (__)(____)(__)  ",
]

WORD = "ARCTIC FOX"


# ---------------------------------------------------------------- widgets --
class HoverButton(tk.Button):
    """Flat modern button with hover feedback."""

    def __init__(self, master, text, command=None, bg=C.deep, fg=C.text,
                 hover_bg=None, active_bg=None, outline=C.border2,
                 size=10, bold=False, padx=14, **kw):
        super().__init__(master, text=text, command=command, bg=bg, fg=fg,
                         activebackground=active_bg or hover_bg or bg,
                         activeforeground=fg, relief="flat", bd=0,
                         font=font_of(size=size, bold=bold),
                         padx=padx, pady=6, cursor="hand2", takefocus=0, **kw)
        self._bg, self._fg = bg, fg
        self._hover = hover_bg or _lighten(bg)
        self.config(highlightthickness=1,
                    highlightbackground=outline, highlightcolor=outline)
        self.bind("<Enter>", lambda e: self.config(bg=self._hover))
        self.bind("<Leave>", lambda e: self.config(bg=self._bg))

    def set_enabled(self, enabled):
        self.config(state="normal" if enabled else "disabled",
                    fg=self._fg if enabled else C.faint,
                    bg=self._bg if enabled else C.panel)


def _lighten(hexcolor, f=0.18):
    h = hexcolor.lstrip("#")
    r, g, b = (int(h[i:i + 2], 16) for i in (0, 2, 4))
    mix = lambda c: int(c + (255 - c) * f)
    return f"#{mix(r):02x}{mix(g):02x}{mix(b):02x}"


def gradient(n, offset=0):
    """n colors walking ice→white→ice; offset slides the wave."""
    stops = [C.blue, C.deep, C.cyan, C.ice, "#BDEBFF", C.white, "#BDEBFF", C.ice]
    out = []
    for i in range(n):
        t = ((i + offset) % (len(stops) * 2)) / (len(stops) * 2 - 1)
        t = 4 * t * (1 - t)  # triangle wave 0..1..0
        j = min(int(t * (len(stops) - 1)), len(stops) - 2)
        f = t * (len(stops) - 1) - j
        a, b = stops[j], stops[j + 1]
        ar, ag, ab = (int(a[k:k + 2], 16) for k in (1, 3, 5))
        br, bg_, bb = (int(b[k:k + 2], 16) for k in (1, 3, 5))
        out.append(f"#{int(ar + (br - ar) * f):02x}"
                   f"{int(ag + (bg_ - ag) * f):02x}"
                   f"{int(ab + (bb - ab) * f):02x}")
    return out


class Header(tk.Canvas):
    """Animated gradient fox art + wordmark."""

    WORD_COLORS = [C.blue, C.deep, C.cyan, C.ice, "#BDEBFF", C.white, "#BDEBFF", C.ice]

    def __init__(self, master):
        super().__init__(master, height=148, bg=C.bg, highlightthickness=0)
        self.art_items, self.word_item = [], None
        self.tick = 0
        self.pack_propagate(False)
        self.bind("<Configure>", lambda e: self.redraw())

    def redraw(self):
        self.delete("all")
        self.art_items = []
        self.word_item = None
        w = max(self.winfo_width(), 900)

        self.create_line(0, 0, 0, 148, fill=C.border)

        # fox art (mono, per-line gradient)
        x, y = 26, 14
        for line in FOX_ART:
            self.art_items.append(
                self.create_text(x, y, text=line, anchor="nw",
                                 font=font_of(mono=True, size=10),
                                 fill=C.ice))
            y += 15

        # divider + text column
        self.create_line(214, 20, 214, 126, fill=C.border)
        self.word_item = self.create_text(230, 24, text=WORD, anchor="nw",
                                          font=font_of(size=26, bold=True),
                                          fill=C.white)
        self.create_text(232, 68, text=core.TAGLINE, anchor="nw",
                         font=font_of(size=10), fill=C.muted)
        self.create_text(232, 90, text="STAY FROSTY  ·  EXPLORE  ·  INSPECT",
                         anchor="nw", font=font_of(size=8, bold=True), fill=C.faint)

        # right side pills
        pw, ph = 150, 24
        self._pill(w - pw - 18, 24, pw, ph, "v" + core.VERSION + "  ·  GUI EDITION",
                   C.card, C.ice)
        self._pill(w - pw - 18, 56, pw, ph, "KALI LINUX", C.card, C.ok)
        self._pill(w - pw - 18, 88, pw, ph, "github.com/arcticfox-cyber",
                   C.card, C.muted, small=True)

        self.shift()

    def _pill(self, x, y, w, h, text, bg, fg, small=False):
        self.create_rounded_rect(x, y, x + w, y + h, 12,
                                 fill=bg, outline=C.border)
        self.create_text(x + w / 2, y + h / 2, text=text, fill=fg,
                         font=font_of(size=8 if small else 9, bold=True))

    def create_rounded_rect(self, x1, y1, x2, y2, r, **kw):
        pts = [x1 + r, y1, x2 - r, y1, x2, y1, x2, y1 + r, x2, y2 - r, x2, y2,
               x2 - r, y2, x1 + r, y2, x1, y2, x1, y2 - r, x1, y1 + r, x1, y1]
        smooth = True
        return self.create_polygon(pts, smooth=smooth, **kw)

    def shift(self):
        """One animation step (called by the app loop)."""
        self.tick += 1
        g_art = gradient(len(FOX_ART), self.tick // 6)
        for item, col in zip(self.art_items, g_art):
            self.itemconfig(item, fill=col)
        if self.word_item is not None:
            self.itemconfig(
                self.word_item,
                fill=self.WORD_COLORS[(self.tick // 8) % len(self.WORD_COLORS)])


# ------------------------------------------------------------------- app --
class App(tk.Tk):
    SPIN = "◐◓◑◒"

    def __init__(self):
        super().__init__()
        core.load_conf()
        self.title(f"{core.APP_NAME} — {core.TAGLINE}  ·  v{core.VERSION}")
        self.geometry("1180x720")
        self.minsize(1020, 620)
        self.configure(bg=C.bg)
        self.q = queue.Queue()
        self.busy = 0
        self.spin_i = 0
        self.user = None
        self.repos, self.gists, self.events, self.orgs = [], [], [], []
        self.avatar_ref = None
        self.repo_sel = None
        self.alive = True

        self._styles()
        self._build()
        self._icon()
        self.after(120, self._loop)
        self.protocol("WM_DELETE_WINDOW", self.on_close)
        self.bind("<Escape>", lambda e: None)

    # ------------------------------------------------------------- setup --
    def _icon(self):
        icon = Path(__file__).resolve().parent / "assets" / "arcticfox-icon.png"
        if icon.exists():
            try:
                self.icon_ref = tk.PhotoImage(file=str(icon))
                self.iconphoto(True, self.icon_ref)
            except Exception:
                pass

    def _styles(self):
        st = ttk.Style(self)
        try:
            st.theme_use("clam")
        except tk.TclError:
            pass
        st.configure(".", background=C.panel, foreground=C.text,
                     fieldbackground=C.card, bordercolor=C.border,
                     lightcolor=C.panel, darkcolor=C.bg, troughcolor=C.bg)
        st.configure("TNotebook", background=C.panel, borderwidth=0, tabmargins=(8, 6, 8, 0))
        st.configure("TNotebook.Tab", background=C.panel, foreground=C.muted,
                     padding=(16, 7), borderwidth=0,
                     font=font_of(size=10, bold=True))
        st.map("TNotebook.Tab",
               background=[("selected", C.card)], foreground=[("selected", C.ice)])
        st.configure("Treeview", background=C.card, foreground=C.text,
                     fieldbackground=C.card, rowheight=28, borderwidth=0,
                     font=font_of(size=9))
        st.map("Treeview",
               background=[("selected", C.selbg)],
               foreground=[("selected", C.white)])
        st.configure("Treeview.Heading", background=C.panel, foreground=C.muted,
                     relief="flat", font=font_of(size=9, bold=True), padding=6)
        st.map("Treeview.Heading", background=[("active", C.border)])
        st.configure("Vertical.TScrollbar", background=C.panel,
                     troughcolor=C.bg, bordercolor=C.bg, arrowcolor=C.muted)
        st.configure("TCombobox", fieldbackground=C.card, background=C.card,
                     foreground=C.text, arrowcolor=C.ice, bordercolor=C.border,
                     lightcolor=C.border, darkcolor=C.border, padding=6)
        self.option_add("*TCombobox*Listbox.background", C.card)
        self.option_add("*TCombobox*Listbox.foreground", C.text)
        self.option_add("*TCombobox*Listbox.selectBackground", C.selbg)

    def _build(self):
        self.header = Header(self)
        self.header.pack(fill="x")

        bar = tk.Frame(self, bg=C.panel, pady=10, padx=14)
        bar.pack(fill="x")
        tk.Label(bar, text="SEARCH", bg=C.panel, fg=C.faint,
                 font=font_of(size=9, bold=True)).pack(side="left", padx=(0, 10))

        self.mode = ttk.Combobox(bar, state="readonly", width=11,
                                 values=list(core.SEARCH_MODES), font=font_of(size=10))
        self.mode.set("Username")
        self.mode.pack(side="left", padx=(0, 8))

        self.entry = tk.Entry(bar, bg=C.card, fg=C.text, insertbackground=C.ice,
                              relief="flat", font=font_of(size=11),
                              highlightthickness=1, highlightbackground=C.border,
                              highlightcolor=C.deep)
        self.entry._ph = True
        self.entry.insert(0, "  Enter a username, full name or email...")
        self.entry.config(fg=C.faint)
        self.entry.bind("<FocusIn>", self._ph_clear, add="+")
        self.entry.bind("<FocusOut>", self._ph_set, add="+")
        self.entry.bind("<Return>", lambda e: self.search())
        self.entry.pack(side="left", fill="x", expand=True, ipady=5, padx=(0, 8))

        self.btn_search = HoverButton(bar, "SEARCH  ▸", command=self.search,
                                      bg=C.ice, fg=C.bg, hover_bg="#9BE0FF",
                                      outline=C.ice, bold=True, size=10)
        self.btn_search.pack(side="left")
        HoverButton(bar, "SETTINGS", command=self.settings_dialog, bg=C.panel,
                    hover_bg=C.border, outline=C.border, size=8, bold=True,
                    padx=12).pack(side="left", padx=(8, 0))

        body = tk.Frame(self, bg=C.bg)
        body.pack(fill="both", expand=True)

        self.profile_card = self._build_profile(body)
        self.profile_card.pack(side="left", fill="both", padx=(14, 8), pady=(4, 8))

        right = tk.Frame(body, bg=C.bg)
        right.pack(side="left", fill="both", expand=True, padx=(0, 14), pady=(4, 8))
        self.tabs = ttk.Notebook(right)
        self.tabs.pack(fill="both", expand=True)
        self._build_repo_tab()
        self._build_gist_tab()
        self._build_event_tab()

        self.stats = self._build_stats()
        self.stats.pack(fill="x", padx=14, pady=(0, 0))

        self._build_statusbar()

    # --------------------------------------------------------- profile card --
    def _build_profile(self, parent):
        card = tk.Frame(parent, bg=C.card, highlightthickness=1,
                        highlightbackground=C.border, width=330, bd=0)
        card.pack_propagate(False)

        top = tk.Frame(card, bg=C.card)
        top.pack(fill="x", padx=16, pady=(16, 6))
        self.avatar = tk.Label(top, bg=C.border2, fg=C.bg, text="?  ",
                               font=font_of(size=26, bold=True), width=6, height=3)
        self.avatar.pack(side="left", padx=(0, 12))
        idbox = tk.Frame(top, bg=C.card)
        idbox.pack(side="left", fill="x", expand=True)
        self.p_name = tk.Label(idbox, text="—", bg=C.card, fg=C.white,
                               font=font_of(size=14, bold=True), anchor="w")
        self.p_name.pack(fill="x")
        self.p_login = tk.Label(idbox, text="search to begin", bg=C.card, fg=C.ice,
                                font=font_of(mono=True, size=10), anchor="w")
        self.p_login.pack(fill="x")
        self.p_type = tk.Label(idbox, text="", bg=C.card, fg=C.white,
                               font=font_of(size=8, bold=True), padx=8, pady=2)
        self.p_type.pack(anchor="w", pady=(4, 0))

        self.p_bio = tk.Label(card, text="", bg=C.card, fg=C.text, justify="left",
                              font=font_of(size=10), wraplength=280, anchor="w")
        self.p_bio.pack(fill="x", padx=16, pady=(4, 8))

        self.p_rows = tk.Frame(card, bg=C.card)
        self.p_rows.pack(fill="x", padx=16)
        self.p_orgs = tk.Label(card, text="", bg=C.card, fg=C.muted, justify="left",
                               font=font_of(size=9), wraplength=280, anchor="w")
        self.p_orgs.pack(fill="x", padx=16, pady=(8, 4))

        btns = tk.Frame(card, bg=C.card)
        btns.pack(side="bottom", fill="x", padx=16, pady=14)
        self.b_open = HoverButton(btns, "↗  Open Profile", command=self.open_profile,
                                  bg=C.deep, hover_bg="#2B7BC0", size=10)
        self.b_open.pack(fill="x", pady=(0, 6))
        self.b_txt = HoverButton(btns, "▤  Save Report (.txt)", command=self.save_txt,
                                 bg=C.panel, hover_bg=C.border, size=10)
        self.b_txt.pack(fill="x", pady=(0, 6))
        self.b_json = HoverButton(btns, "{ }  Export Data (.json)", command=self.export_json,
                                  bg=C.panel, hover_bg=C.border, size=10)
        self.b_json.pack(fill="x")
        for b in (self.b_open, self.b_txt, self.b_json):
            b.set_enabled(False)
        return card

    def _prof_row(self, key):
        row = tk.Frame(self.p_rows, bg=C.card)
        row.pack(fill="x", pady=2)
        tk.Label(row, text=key, width=9, anchor="w", bg=C.card, fg=C.faint,
                 font=font_of(size=9, bold=True)).pack(side="left")
        lbl = tk.Label(row, text="—", anchor="w", bg=C.card, fg=C.text,
                       font=font_of(size=9), wraplength=220, justify="left")
        lbl.pack(side="left", fill="x", expand=True)
        return lbl

    # ---------------------------------------------------------------- tabs --
    def _tree(self, parent, cols, widths, anchor="w"):
        wrap = tk.Frame(parent, bg=C.card)
        tv = ttk.Treeview(wrap, columns=cols, show="headings", selectmode="browse")
        for c, w in zip(cols, widths):
            tv.heading(c, text=c.upper())
            tv.column(c, width=w, anchor=anchor, stretch=(w >= 200))
        vs = ttk.Scrollbar(wrap, orient="vertical", command=tv.yview)
        tv.configure(yscrollcommand=vs.set)
        vs.pack(side="right", fill="y")
        tv.pack(fill="both", expand=True)
        tv.tag_configure("odd", background=C.card)
        tv.tag_configure("even", background=C.card2)
        return wrap, tv

    def _build_repo_tab(self):
        f = tk.Frame(self.tabs, bg=C.card)
        self.tabs.add(f, text=" Repositories ")
        wrap, self.tv_repos = self._tree(
            f, ("#", "Repository", "Language", "STARS", "FORKS", "Updated", "Description"),
            (44, 230, 110, 70, 60, 90, 330))
        wrap.pack(fill="both", expand=True)
        self.tv_repos.bind("<<TreeviewSelect>>", self._on_repo_select)
        self.tv_repos.bind("<Double-1>", lambda e: self.details_selected())

        act = tk.Frame(f, bg=C.panel, padx=10, pady=8)
        act.pack(fill="x", side="bottom")
        self.b_clone = HoverButton(act, "▼  CLONE", command=self.clone_selected,
                                   bg=C.ice, fg=C.bg, hover_bg="#9BE0FF",
                                   outline=C.ice, bold=True)
        self.b_clone.pack(side="left", padx=(0, 8))
        self.b_details = HoverButton(act, "Details", command=self.details_selected,
                                     bg=C.card, hover_bg=C.border, outline=C.border)
        self.b_details.pack(side="left", padx=(0, 8))
        self.b_gh = HoverButton(act, "↗  Open on GitHub", command=self.open_selected,
                                bg=C.card, hover_bg=C.border, outline=C.border)
        self.b_gh.pack(side="left")
        tk.Label(act, text="double-click a row for full details",
                 bg=C.panel, fg=C.faint, font=font_of(size=8)).pack(side="right")
        for b in (self.b_clone, self.b_details, self.b_gh):
            b.set_enabled(False)

    def _build_gist_tab(self):
        f = tk.Frame(self.tabs, bg=C.card)
        self.tabs.add(f, text=" Gists ")
        wrap, self.tv_gists = self._tree(
            f, ("Gist", "URL"), (430, 520))
        wrap.pack(fill="both", expand=True)

    def _build_event_tab(self):
        f = tk.Frame(self.tabs, bg=C.card)
        self.tabs.add(f, text=" Activity ")
        wrap, self.tv_events = self._tree(
            f, ("When", "Event", "Repository"), (170, 200, 580))
        wrap.pack(fill="both", expand=True)

    # ------------------------------------------------------------ stats bar --
    def _build_stats(self):
        bar = tk.Frame(self, bg=C.panel, highlightthickness=1,
                       highlightbackground=C.border, pady=8, padx=14)
        self.chips = {}
        defs = (("REPOS", C.ice), ("STARS ★", C.warn), ("FORKS", C.cyan),
                ("TOP LANG", "#A78BFA"), ("FOLLOWERS", C.ok))
        for name, color in defs:
            box = tk.Frame(bar, bg=C.panel)
            box.pack(side="left", padx=(0, 26))
            tk.Label(box, text=name, bg=C.panel, fg=C.faint,
                     font=font_of(size=8, bold=True)).pack(anchor="w")
            val = tk.Label(box, text="0", bg=C.panel, fg=color,
                           font=font_of(size=13, bold=True, mono=True))
            val.pack(anchor="w")
            self.chips[name] = val
        tk.Label(bar, text="reports saved to ~/arctic-fox-reports", bg=C.panel, fg=C.faint,
                 font=font_of(size=8)).pack(side="right")
        return bar

    # ----------------------------------------------------------- status bar --
    def _build_statusbar(self):
        bar = tk.Frame(self, bg=C.bg, pady=6, padx=14)
        bar.pack(fill="x", side="bottom")
        self.spin = tk.Label(bar, text="", bg=C.bg, fg=C.ice,
                             font=font_of(mono=True, size=10, bold=True), width=2)
        self.spin.pack(side="left")
        self.status = tk.Label(bar, text="Ready — search any GitHub account.",
                               bg=C.bg, fg=C.muted, font=font_of(size=9), anchor="w")
        self.status.pack(side="left", fill="x", expand=True)
        self.api_state = tk.Label(bar, text="token: off · api.github.com",
                                  bg=C.bg, fg=C.faint, font=font_of(size=8, mono=True))
        self.api_state.pack(side="right")
        self._api_state_refresh()

    def _api_state_refresh(self):
        on = bool(core.CONF["token"])
        self.api_state.config(text=f"token: {'on ' if on else 'off'} · api.github.com",
                              fg=C.ok if on else C.faint)

    # ------------------------------------------------------ status helpers --
    def set_status(self, msg, busy=False):
        self.status.config(text=msg)

    def _post(self, fn, *a):
        self.q.put((fn, a))

    def _loop(self):
        if not self.alive:
            return
        if self.busy > 0:
            self.spin_i = (self.spin_i + 1) % len(self.SPIN)
            self.spin.config(text=self.SPIN[self.spin_i])
        else:
            self.spin.config(text="")
        self.header.shift()
        while True:
            try:
                fn, a = self.q.get_nowait()
            except queue.Empty:
                break
            try:
                fn(*a)
            except Exception as e:  # never let the UI thread die
                self.set_status(f"UI error: {e}")
        self.after(120, self._loop)

    def _busy_start(self):
        self.busy += 1
        self.btn_search.config(state="disabled", fg=C.bg)

    def _busy_end(self):
        self.busy = max(0, self.busy - 1)
        if self.busy == 0:
            self.btn_search.config(state="normal", fg=C.bg)

    # ----------------------------------------------------------- placeholder --
    def _ph_clear(self, _=None):
        if getattr(self.entry, "_ph", False):
            self.entry.delete(0, "end")
            self.entry.config(fg=C.text)
            self.entry._ph = False

    def _ph_set(self, _=None):
        if not self.entry.get().strip():
            self.entry._ph = True
            self.entry.delete(0, "end")
            self.entry.insert(0, "  Enter a username, full name or email...")
            self.entry.config(fg=C.faint)

    # -------------------------------------------------------------- search --
    def search(self):
        if self.busy:
            return
        self._ph_clear()
        text = self.entry.get().strip().lstrip("@")
        if not text or getattr(self.entry, "_ph", False):
            self.set_status("Type a username first.")
            return
        mode = self.mode.get()
        if mode == "Username":
            self.load_profile(text)
        else:
            self.user_search(text, mode)

    def load_profile(self, login):
        self._busy_start()
        self.set_status(f"Fetching @{login} …")
        threading.Thread(target=self._t_profile, args=(login,), daemon=True).start()

    def _t_profile(self, login):
        try:
            u = core.gh_api(f"/users/{login}")
        except core.ApiError as e:
            self._post(self._busy_end)
            self._post(self._search_failed, str(e))
            return
        self._post(self._render_profile, u)
        try:
            orgs = core.gh_api(f"/users/{login}/orgs")
        except core.ApiError:
            orgs = []
        self._post(self._render_orgs, orgs)
        self._post(self.set_status, "Fetching repositories …")
        try:
            repos = core.gh_api_all(f"/users/{login}/repos", {"sort": "updated"})
        except core.ApiError as e:
            repos = []
            self._post(self.set_status, f"Repos: {e}")
        self._post(self._render_repos, repos)
        try:
            gists = core.gh_api_all(f"/users/{login}/gists", cap=100)
        except core.ApiError:
            gists = []
        self._post(self._render_gists, gists)
        self._post(self.set_status, "Fetching recent activity …")
        try:
            events = core.gh_api(f"/users/{login}/events/public", {"per_page": 15})
        except core.ApiError:
            events = []
        self._post(self._render_events, events)
        self._post(self._done, f"@{u['login']} loaded — {len(repos)} repositories.")
        self._post(self._fetch_avatar, u)

    def _fetch_avatar(self, u):
        threading.Thread(target=self._t_avatar, args=(u,), daemon=True).start()

    def _t_avatar(self, u):
        try:
            raw = core.fetch_bytes(u["avatar_url"] + ("&" if "?" in u["avatar_url"] else "?") + "size=128")
            b64 = base64.b64encode(raw).decode()
            self._post(self._render_avatar, b64, u.get("name") or u["login"])
        except Exception:
            pass

    def _render_avatar(self, b64, name):
        try:
            img = tk.PhotoImage(data=b64)
            if img.width() > 88:
                img = img.subsample(int(math.ceil(img.width() / 88)))
            self.avatar_ref = img
            self.avatar.config(image=img, text="", width=88, height=88, bg=C.border2)
        except Exception:
            self._initials(name)

    def _initials(self, name):
        self.avatar.config(image="", text=" ".join((name or "?")[:2]).upper() + " ",
                           bg=C.deep, fg=C.ice)

    def _search_failed(self, msg):
        self.set_status(msg)
        messagebox.showwarning("Arctic Fox", msg)

    def _done(self, msg):
        self._busy_end()
        self.set_status(msg)

    # ------------------------------------------------------- user search mode --
    def user_search(self, text, mode):
        self._busy_start()
        self.set_status(f"Searching users — {mode.lower()} “{text}” …")
        threading.Thread(target=self._t_user_search, args=(text, mode),
                         daemon=True).start()

    def _t_user_search(self, text, mode):
        try:
            items = core.search_users(text, mode)
        except core.ApiError as e:
            self._post(self._busy_end)
            self._post(self._search_failed, str(e))
            return
        self._post(self._show_user_results, items, text, mode)
        self._post(self._busy_end)

    def _show_user_results(self, items, text, mode):
        if not items:
            self.set_status(f"No users matched “{text}” ({mode.lower()}).")
            return
        win = tk.Toplevel(self)
        win.title(f"User results — “{text}” ({len(items)})")
        win.geometry("640x420")
        win.configure(bg=C.bg)
        win.transient(self)
        wrap, tv = self._tree(win, ("Login", "Type"), (300, 200))
        wrap.pack(fill="both", expand=True, padx=12, pady=12)
        for i, it in enumerate(items):
            tv.insert("", "end", iid=str(i),
                      values=(it.get("login"), it.get("type", "User")),
                      tags=("odd" if i % 2 else "even",))

        def view(_=None):
            sel = tv.selection()
            if sel:
                win.destroy()
                self.mode.set("Username")
                self._ph_clear()
                self.entry.delete(0, "end")
                self.entry.insert(0, tv.item(sel[0], "values")[0])
                self.load_profile(tv.item(sel[0], "values")[0])

        btns = tk.Frame(win, bg=C.bg)
        btns.pack(fill="x", padx=12, pady=(0, 12))
        HoverButton(btns, "→  View Profile", command=view, bg=C.ice, fg=C.bg,
                    hover_bg="#9BE0FF", outline=C.ice, bold=True).pack(side="left")
        tk.Label(btns, text="double-click a result to open it",
                 bg=C.bg, fg=C.faint, font=font_of(size=8)).pack(side="right")
        tv.bind("<Double-1>", view)
        self.set_status(f"{len(items)} users matched “{text}”.")

    # ------------------------------------------------------------- renderers --
    def _render_profile(self, u):
        self.user = u
        name = u.get("name") or u["login"]
        self.p_name.config(text=name)
        self.p_login.config(text="@" + u["login"])
        self.p_type.config(text=u["type"], bg=C.selbg)
        self.p_bio.config(text=u.get("bio") or "")
        for w in self.p_rows.winfo_children():
            w.destroy()
        rows = [("Location", u.get("location")), ("Company", u.get("company")),
                ("Website", u.get("blog")), ("Twitter", ("@" + u["twitter_username"])
                        if u.get("twitter_username") else None),
                ("Email", u.get("email")), ("Joined", u["created_at"][:10]),
                ("Updated", u["updated_at"][:10])]
        self._row_labels = [self._prof_row(k) for k, _ in rows]
        for lbl, (_, v) in zip(self._row_labels, rows):
            lbl.config(text=v or "—", fg=C.text if v else C.faint)
        self._initials(name)
        for b in (self.b_open, self.b_txt, self.b_json):
            b.set_enabled(True)

    def _render_orgs(self, orgs):
        self.orgs = orgs
        if orgs:
            self.p_orgs.config(text="ORGs:  " + ", ".join(o["login"] for o in orgs[:8]),
                               fg=C.muted)
        else:
            self.p_orgs.config(text="")

    def _render_repos(self, repos):
        self.repos = repos
        self.tv_repos.delete(*self.tv_repos.get_children())
        for i, r in enumerate(repos):
            desc = (r.get("description") or "")[:60]
            self.tv_repos.insert("", "end", iid=str(i), tags=("odd" if i % 2 else "even"),
                                 values=(f"{i+1:03d}", r["name"], r.get("language") or "—",
                                         core.fmt(r.get("stargazers_count", 0)),
                                         core.fmt(r.get("forks_count", 0)),
                                         r["updated_at"][:10], desc))
        self.tabs.tab(0, text=f" Repositories · {len(repos)} ")
        for b in (self.b_clone, self.b_details, self.b_gh):
            b.set_enabled(False)
        self.repo_sel = None
        self._update_stats()

    def _render_gists(self, gists):
        self.gists = gists
        self.tv_gists.delete(*self.tv_gists.get_children())
        for i, g in enumerate(gists):
            self.tv_gists.insert("", "end", tags=("odd" if i % 2 else "even"),
                                 values=(g.get("description") or "(no description)",
                                         g["html_url"]))
        self.tabs.tab(1, text=f" Gists · {len(gists)} ")

    def _render_events(self, events):
        self.events = events
        self.tv_events.delete(*self.tv_events.get_children())
        for i, e in enumerate(events):
            self.tv_events.insert("", "end", tags=("odd" if i % 2 else "even"),
                                  values=(e["created_at"][:16].replace("T", " "),
                                          e.get("type", ""), e["repo"]["name"]))
        self.tabs.tab(2, text=f" Activity · {len(events)} ")

    def _update_stats(self):
        if not self.user:
            return
        s = core.stats_summary(self.user, self.repos)
        self.chips["REPOS"].config(text=core.fmt(s["repos"]))
        self.chips["STARS ★"].config(text=core.fmt(s["stars"]))
        self.chips["FORKS"].config(text=core.fmt(s["forks"]))
        self.chips["TOP LANG"].config(text=str(s["top_language"]))
        self.chips["FOLLOWERS"].config(text=core.fmt(s["followers"]))

    # --------------------------------------------------------- repo actions --
    def _on_repo_select(self, _=None):
        sel = self.tv_repos.selection()
        if not sel or not self.repos:
            return
        self.repo_sel = self.repos[int(sel[0])]
        for b in (self.b_clone, self.b_details, self.b_gh):
            b.set_enabled(True)

    def _sel_full(self):
        if not self.repo_sel:
            messagebox.showinfo("Arctic Fox", "Select a repository first.")
            return None
        return self.repo_sel["full_name"]

    def clone_selected(self):
        full = self._sel_full()
        if not full or self.busy:
            return
        self._busy_start()
        self.set_status(f"Cloning {full} …")

        def on_line(t):
            self._post(self.set_status, f"Cloning {full} — {t}")

        def on_done(ok_, msg):
            self._post(self._clone_done, ok_, msg)

        threading.Thread(target=core.clone_repo,
                         args=(full, core.CONF["clone_dir"], on_line, on_done),
                         daemon=True).start()

    def _clone_done(self, ok_, msg):
        self._busy_end()
        self.set_status(msg)
        (messagebox.showinfo if ok_ else messagebox.showerror)("Clone", msg)

    def details_selected(self):
        full = self._sel_full()
        if not full or self.busy:
            return
        self._busy_start()
        self.set_status(f"Fetching details for {full} …")

        def t():
            try:
                d = core.gh_api(f"/repos/{full}")
            except core.ApiError as e:
                self._post(self._busy_end)
                self._post(self._search_failed, str(e))
                return
            self._post(self._show_repo_details, d)
            self._post(self._busy_end)

        threading.Thread(target=t, daemon=True).start()

    def _show_repo_details(self, d):
        win = tk.Toplevel(self)
        win.title(f"Repo details — {d['full_name']}")
        win.geometry("560x520")
        win.configure(bg=C.bg)
        win.transient(self)
        head = tk.Frame(win, bg=C.card, padx=16, pady=12)
        head.pack(fill="x")
        tk.Label(head, text=d["name"], bg=C.card, fg=C.white,
                 font=font_of(size=15, bold=True)).pack(anchor="w")
        tk.Label(head, text=d.get("description") or "—", bg=C.card, fg=C.muted,
                 font=font_of(size=9), wraplength=500, justify="left").pack(anchor="w")
        body = tk.Frame(win, bg=C.bg, padx=16, pady=12)
        body.pack(fill="both", expand=True)
        info = [("Full name", d["full_name"]),
                ("Stars / Forks / Watch", f"{d['stargazers_count']} ★   {d['forks_count']} forks   {d.get('subscribers_count', 0)} watch"),
                ("Language", d.get("language") or "—"),
                ("License", (d.get("license") or {}).get("spdx_id") or "none"),
                ("Created", d["created_at"][:10]),
                ("Last push", d["pushed_at"][:10]),
                ("Size", f"{d.get('size', 0)} KB"),
                ("Open issues", d.get("open_issues_count", 0)),
                ("Homepage", d.get("homepage") or "—")]
        for k, v in info:
            row = tk.Frame(body, bg=C.bg)
            row.pack(fill="x", pady=3)
            tk.Label(row, text=k, width=20, anchor="w", bg=C.bg, fg=C.faint,
                     font=font_of(size=9, bold=True)).pack(side="left")
            tk.Label(row, text=str(v), anchor="w", bg=C.bg, fg=C.text,
                     font=font_of(size=9), wraplength=330,
                     justify="left").pack(side="left", fill="x", expand=True)
        topics = d.get("topics") or []
        if topics:
            tk.Label(body, text="TOPICS", bg=C.bg, fg=C.faint,
                     font=font_of(size=8, bold=True)).pack(anchor="w", pady=(8, 2))
            chips = tk.Frame(body, bg=C.bg)
            chips.pack(anchor="w")
            for t in topics[:10]:
                tk.Label(chips, text=t, bg=C.card, fg=C.ice, padx=8, pady=2,
                         font=font_of(size=8)).pack(side="left", padx=3)
        HoverButton(win, "↗  Open on GitHub",
                    command=lambda: webbrowser.open(d["html_url"]),
                    bg=C.ice, fg=C.bg, hover_bg="#9BE0FF", outline=C.ice,
                    bold=True).pack(pady=10)

    def open_selected(self):
        full = self._sel_full()
        if full:
            webbrowser.open(f"https://github.com/{full}")

    def open_profile(self):
        if self.user:
            webbrowser.open(self.user["html_url"])

    # ------------------------------------------------------------- exports --
    def _need_user(self):
        if not self.user:
            messagebox.showinfo("Arctic Fox", "Load a profile first.")
            return False
        return True

    def save_txt(self):
        if not self._need_user():
            return
        try:
            f = core.save_report(self.user, self.repos, self.gists, self.events)
            self.set_status(f"Report saved → {f}")
            messagebox.showinfo("Report saved", str(f))
        except OSError as e:
            messagebox.showerror("Save failed", str(e))

    def export_json(self):
        if not self._need_user():
            return
        try:
            f = core.save_json(self.user, self.repos, self.gists, self.events)
            self.set_status(f"JSON export → {f}")
            messagebox.showinfo("JSON exported", str(f))
        except OSError as e:
            messagebox.showerror("Export failed", str(e))

    # ------------------------------------------------------------- settings --
    def settings_dialog(self):
        win = tk.Toplevel(self)
        win.title("Settings — Arctic Fox")
        win.geometry("520x290")
        win.configure(bg=C.bg)
        win.transient(self)
        win.resizable(False, False)
        fr = tk.Frame(win, bg=C.bg, padx=20, pady=16)
        fr.pack(fill="both", expand=True)

        tk.Label(fr, text="GITHUB TOKEN  (optional — higher rate limits)",
                 bg=C.bg, fg=C.faint, font=font_of(size=8, bold=True)).pack(anchor="w")
        tok = tk.Entry(fr, bg=C.card, fg=C.text, relief="flat", show="•",
                       insertbackground=C.ice, font=font_of(mono=True, size=10))
        tok.pack(fill="x", ipady=5, pady=(4, 2))
        if core.CONF["token"]:
            tok.insert(0, core.CONF["token"])
        tk.Label(fr, text="github.com/settings/tokens → classic token, no scope needed for public data",
                 bg=C.bg, fg=C.faint, font=font_of(size=8)).pack(anchor="w", pady=(0, 12))

        tk.Label(fr, text="CLONE DIRECTORY", bg=C.bg, fg=C.faint,
                 font=font_of(size=8, bold=True)).pack(anchor="w")
        drow = tk.Frame(fr, bg=C.bg)
        drow.pack(fill="x", pady=(4, 2))
        d = tk.Entry(drow, bg=C.card, fg=C.text, relief="flat",
                     insertbackground=C.ice, font=font_of(mono=True, size=10))
        d.pack(side="left", fill="x", expand=True, ipady=5)
        d.insert(0, core.CONF["clone_dir"])

        def browse():
            p = filedialog.askdirectory(parent=win)
            if p:
                d.delete(0, "end")
                d.insert(0, p)

        HoverButton(drow, "…", command=browse, bg=C.panel,
                    hover_bg=C.border, padx=10).pack(side="left", padx=(8, 0))

        def save():
            core.CONF["token"] = tok.get().strip()
            if d.get().strip():
                core.CONF["clone_dir"] = d.get().strip()
            core.save_conf()
            self._api_state_refresh()
            self.set_status("Settings saved.")
            win.destroy()

        btns = tk.Frame(fr, bg=C.bg)
        btns.pack(fill="x", pady=(14, 0))
        HoverButton(btns, "SAVE", command=save, bg=C.ice, fg=C.bg,
                    hover_bg="#9BE0FF", outline=C.ice, bold=True).pack(side="left")
        HoverButton(btns, "CANCEL", command=win.destroy, bg=C.panel,
                    hover_bg=C.border).pack(side="left", padx=8)

    # ---------------------------------------------------------------- misc --
    def on_close(self):
        self.alive = False
        self.destroy()


def main():
    args = [a for a in sys.argv[1:]]
    here = Path(__file__).resolve().parent

    if args and args[0] in ("-v", "--version"):
        print(f"{core.APP_NAME} {core.VERSION} (GUI edition)")
        return
    if args and args[0] in ("-h", "--help"):
        print(__doc__)
        return
    if args and args[0] == "--cli":
        os.execv(sys.executable, [sys.executable, str(here / "arcticfox-cli.py")] + args[1:])

    try:
        app = App()
    except tk.TclError as exc:                       # no X display / broken X
        _gui_unavailable(str(exc))
    target = args[0].lstrip("@").strip() if args else ""
    if target:
        app.entry.delete(0, "end")
        app.entry.insert(0, target)
        app.after(300, app.search)
    app.mainloop()


if __name__ == "__main__":
    main()
